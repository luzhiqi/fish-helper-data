package com.tpnet.tpautoverifycode.callback;

/**
 * 输入验证码完成
 * Created by litp on 2017/7/24.
 */

public interface OnInputCompleteListener {
    void onInputComplete(String text);
}
